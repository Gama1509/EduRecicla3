import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Product } from '../entities/product.entity';
import { LaptopSpecs } from '../entities/laptop-specs.entity';
import { LaptopsController } from './laptops.controller';
import { LaptopsService } from './laptops.service';

@Module({
  imports: [TypeOrmModule.forFeature([Product, LaptopSpecs])],
  controllers: [LaptopsController],
  providers: [LaptopsService],
})
export class LaptopsModule {}
